#!/bin/bash

# You should link DanmakuFactory binary and DanmakuFactoryConfig.json into /usr/bin first
# Run script with crontab may got better experience.

WORK_DIR=/data/blrec

cd $WORK_DIR

function Danmaku(){
    for file in `ls $1`
    do
        if [ -d $1"/"$file ]
        then
            cd
            Danmaku $1"/"$file
        else
            if [[ $file =~ xml ]]
            then
                echo $file
                output=${file%%.*}
                DanmakuFactory -i $1"/"$file -o $1"/""${file%%.*}".ass --ignore-warnings
            fi
        fi
    done
}

Danmaku $WORK_DIR